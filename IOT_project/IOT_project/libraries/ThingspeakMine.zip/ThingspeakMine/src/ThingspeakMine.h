void ConnectToThingSpeak();
void ConnectToThingSpeakForSpeed(long);
void ConnectToThingSpeakForTilt(long);
void ConnectToThingSpeakForDistance(long);
void ConnectToThingSpeakForTemperature(long);
