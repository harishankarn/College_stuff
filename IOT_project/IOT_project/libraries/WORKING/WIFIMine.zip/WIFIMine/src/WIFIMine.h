boolean CheckWIFI();
void WIFIInit();