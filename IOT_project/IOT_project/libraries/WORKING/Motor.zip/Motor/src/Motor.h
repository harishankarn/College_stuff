

void BLEInit();
void SetMotorService();
void BLEAdvertise();
void Motor();
void Backward();
void Forward();
void Stop();
void Left();
void Right();
void DigitalWrite();
void AnalogWrite();
void PinMode();

